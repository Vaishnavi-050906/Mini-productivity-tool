# FocusFlow — VS Code setup

## Install

```cmd
pnpm install
```

## Frontend

```cmd
set PORT=5173
set BASE_PATH=/
pnpm --filter @workspace/focusflow run dev
```

Open: http://localhost:5173

## Backend

The API server needs PostgreSQL and DATABASE_URL:

```cmd
set PORT=4000
set DATABASE_URL=postgresql://postgres:YOUR_PASSWORD@localhost:5432/focusflow
pnpm --filter @workspace/api-server run dev
```

## Pages

- / — Landing
- /timer — Timer, mood selector, accuracy and alerts
- /tasks — Tasks with priorities and filters
- /notes — Create, edit and delete notes
- /stats — Focus score, points, levels, accuracy and chart
