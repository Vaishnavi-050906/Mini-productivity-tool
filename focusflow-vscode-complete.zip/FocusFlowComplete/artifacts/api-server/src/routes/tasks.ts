import { Router, type IRouter } from "express";
import { db, tasksTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import {
  CreateTaskBody,
  UpdateTaskBody,
  UpdateTaskParams,
  DeleteTaskParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/tasks", async (req, res) => {
  try {
    const tasks = await db.select().from(tasksTable).orderBy(tasksTable.createdAt);
    res.json(tasks);
  } catch (err) {
    req.log.error(err, "Failed to get tasks");
    res.status(500).json({ error: "Failed to get tasks" });
  }
});

router.post("/tasks", async (req, res) => {
  try {
    const body = CreateTaskBody.parse(req.body);
    const [task] = await db
      .insert(tasksTable)
      .values({
        title: body.title,
        description: body.description ?? null,
        priority: body.priority,
        completed: false,
      })
      .returning();
    res.status(201).json(task);
  } catch (err) {
    req.log.error(err, "Failed to create task");
    res.status(400).json({ error: "Failed to create task" });
  }
});

router.patch("/tasks/:id", async (req, res) => {
  try {
    const { id } = UpdateTaskParams.parse(req.params);
    const body = UpdateTaskBody.parse(req.body);
    const [task] = await db
      .update(tasksTable)
      .set({
        ...body,
        updatedAt: new Date(),
      })
      .where(eq(tasksTable.id, id))
      .returning();
    if (!task) {
      return res.status(404).json({ error: "Task not found" });
    }
    res.json(task);
  } catch (err) {
    req.log.error(err, "Failed to update task");
    res.status(400).json({ error: "Failed to update task" });
  }
});

router.delete("/tasks/:id", async (req, res) => {
  try {
    const { id } = DeleteTaskParams.parse(req.params);
    await db.delete(tasksTable).where(eq(tasksTable.id, id));
    res.status(204).send();
  } catch (err) {
    req.log.error(err, "Failed to delete task");
    res.status(400).json({ error: "Failed to delete task" });
  }
});

export default router;
