import { Router, type IRouter } from "express";
import { db, sessionsTable } from "@workspace/db";
import { CreateSessionBody } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/sessions", async (req, res) => {
  try {
    const sessions = await db.select().from(sessionsTable).orderBy(sessionsTable.completedAt);
    res.json(sessions);
  } catch (err) {
    req.log.error(err, "Failed to get sessions");
    res.status(500).json({ error: "Failed to get sessions" });
  }
});

router.post("/sessions", async (req, res) => {
  try {
    const body = CreateSessionBody.parse(req.body);
    const [session] = await db
      .insert(sessionsTable)
      .values({
        type: body.type,
        durationMinutes: body.durationMinutes,
        taskId: body.taskId ?? null,
      })
      .returning();
    res.status(201).json(session);
  } catch (err) {
    req.log.error(err, "Failed to create session");
    res.status(400).json({ error: "Failed to create session" });
  }
});

export default router;
