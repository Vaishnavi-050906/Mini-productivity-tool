import { Router, type IRouter } from "express";
import healthRouter from "./health";
import tasksRouter from "./tasks";
import notesRouter from "./notes";
import sessionsRouter from "./sessions";

const router: IRouter = Router();

router.use(healthRouter);
router.use(tasksRouter);
router.use(notesRouter);
router.use(sessionsRouter);

export default router;
