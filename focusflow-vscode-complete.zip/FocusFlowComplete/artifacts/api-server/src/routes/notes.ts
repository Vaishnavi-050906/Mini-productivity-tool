import { Router, type IRouter } from "express";
import { db, notesTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import {
  CreateNoteBody,
  UpdateNoteBody,
  UpdateNoteParams,
  DeleteNoteParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/notes", async (req, res) => {
  try {
    const notes = await db.select().from(notesTable).orderBy(notesTable.updatedAt);
    res.json(notes);
  } catch (err) {
    req.log.error(err, "Failed to get notes");
    res.status(500).json({ error: "Failed to get notes" });
  }
});

router.post("/notes", async (req, res) => {
  try {
    const body = CreateNoteBody.parse(req.body);
    const [note] = await db
      .insert(notesTable)
      .values({
        title: body.title,
        content: body.content,
      })
      .returning();
    res.status(201).json(note);
  } catch (err) {
    req.log.error(err, "Failed to create note");
    res.status(400).json({ error: "Failed to create note" });
  }
});

router.patch("/notes/:id", async (req, res) => {
  try {
    const { id } = UpdateNoteParams.parse(req.params);
    const body = UpdateNoteBody.parse(req.body);
    const [note] = await db
      .update(notesTable)
      .set({
        ...body,
        updatedAt: new Date(),
      })
      .where(eq(notesTable.id, id))
      .returning();
    if (!note) {
      return res.status(404).json({ error: "Note not found" });
    }
    res.json(note);
  } catch (err) {
    req.log.error(err, "Failed to update note");
    res.status(400).json({ error: "Failed to update note" });
  }
});

router.delete("/notes/:id", async (req, res) => {
  try {
    const { id } = DeleteNoteParams.parse(req.params);
    await db.delete(notesTable).where(eq(notesTable.id, id));
    res.status(204).send();
  } catch (err) {
    req.log.error(err, "Failed to delete note");
    res.status(400).json({ error: "Failed to delete note" });
  }
});

export default router;
