import { Link } from "wouter";
import { motion } from "framer-motion";
import { Brain, ArrowRight, Zap, Target, BarChart, Sparkles, Trophy, Smile, Star } from "lucide-react";
import { useGamification } from "@/hooks/useGamification";

export default function Landing() {
  const { totalPoints, currentLevel, focusScore, completedTasksCount } = useGamification();

  const features = [
    {
      icon: <Target className="w-6 h-6 text-primary" />,
      title: "Mood-Adaptive Timer",
      description: "Choose Lazy, Normal, or Focused mode — the Pomodoro timer adjusts to how you feel.",
      badge: "New",
    },
    {
      icon: <Zap className="w-6 h-6 text-accent" />,
      title: "Task Manager",
      description: "Organize priorities, mark tasks complete, and earn points for every win.",
      badge: null,
    },
    {
      icon: <Trophy className="w-6 h-6 text-amber-400" />,
      title: "Gamification & Levels",
      description: "Earn XP, level up from Rookie to Legend, and track your productivity streak.",
      badge: "New",
    },
    {
      icon: <BarChart className="w-6 h-6 text-blue-400" />,
      title: "Focus Score",
      description: "A real-time score (0–100) based on tasks done and focus time — know exactly how productive you are.",
      badge: "New",
    },
    {
      icon: <Sparkles className="w-6 h-6 text-emerald-400" />,
      title: "Quick Notes",
      description: "Jot down brilliant ideas instantly without breaking your flow.",
      badge: null,
    },
    {
      icon: <Smile className="w-6 h-6 text-rose-400" />,
      title: "Mood Selector",
      description: "Three modes for any energy level: 15, 25, or 50 minute focus sessions.",
      badge: "New",
    },
  ];

  const hasActivity = totalPoints > 0;

  return (
    <div className="min-h-screen pt-24 pb-12 flex flex-col items-center relative overflow-hidden">
      {/* Background */}
      <div className="absolute top-0 left-0 w-full h-[80vh] -z-10 opacity-40">
        <img
          src={`${import.meta.env.BASE_URL}images/hero-bg.png`}
          alt="Abstract Background"
          className="w-full h-full object-cover"
          style={{ maskImage: "linear-gradient(to bottom, black 0%, transparent 100%)", WebkitMaskImage: "-webkit-linear-gradient(top, black 0%, transparent 100%)" }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-background" />
      </div>
      <div className="absolute top-[20%] left-1/2 -translate-x-1/2 w-[700px] h-[400px] bg-primary/15 blur-[140px] rounded-full -z-10 pointer-events-none" />

      <div className="w-full max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col items-center text-center mt-12 md:mt-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-panel border-primary/20 text-primary mb-8"
        >
          <Sparkles className="w-4 h-4" />
          <span className="text-sm font-medium">Hackathon Edition v2.0 — Now with Gamification!</span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="text-5xl md:text-7xl lg:text-8xl font-display font-extrabold tracking-tight mb-6"
        >
          Stay focused.{" "}
          <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-accent to-blue-500">
            Level up.
          </span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="text-lg md:text-xl text-muted-foreground max-w-2xl mb-12"
        >
          FocusFlow turns productivity into a game. Earn points, level up, track your Focus Score, and choose your mood — all in one seamless tool.
        </motion.p>

        {/* Live stats preview if user has activity */}
        {hasActivity && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.25 }}
            className="flex items-center gap-4 mb-8 flex-wrap justify-center"
          >
            <div className="glass-panel px-5 py-3 rounded-2xl flex items-center gap-3 border border-primary/20">
              <span className="text-2xl">{currentLevel.badge}</span>
              <div className="text-left">
                <p className={`text-sm font-bold ${currentLevel.color}`}>{currentLevel.title}</p>
                <p className="text-xs text-muted-foreground">Level {currentLevel.level}</p>
              </div>
            </div>
            <div className="glass-panel px-5 py-3 rounded-2xl flex items-center gap-3 border border-amber-400/20">
              <Star className="w-5 h-5 text-amber-400" />
              <div className="text-left">
                <p className="text-sm font-bold text-amber-400">{totalPoints} pts</p>
                <p className="text-xs text-muted-foreground">Total points</p>
              </div>
            </div>
            <div className="glass-panel px-5 py-3 rounded-2xl flex items-center gap-3 border border-emerald-400/20">
              <Zap className="w-5 h-5 text-emerald-400" />
              <div className="text-left">
                <p className="text-sm font-bold text-emerald-400">Score: {focusScore}</p>
                <p className="text-xs text-muted-foreground">{completedTasksCount} tasks done</p>
              </div>
            </div>
          </motion.div>
        )}

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
          <Link
            href="/timer"
            className="group relative inline-flex items-center justify-center gap-3 px-8 py-4 bg-primary text-primary-foreground font-semibold rounded-2xl overflow-hidden transition-transform hover:scale-105 active:scale-95 shadow-2xl shadow-primary/30"
          >
            <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300 ease-out" />
            <Brain className="w-5 h-5 relative z-10" />
            <span className="relative z-10 text-lg">{hasActivity ? "Continue" : "Launch"} FocusFlow</span>
            <ArrowRight className="w-5 h-5 relative z-10 group-hover:translate-x-1 transition-transform" />
          </Link>
        </motion.div>

        {/* Features Grid */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.5 }}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-28 w-full"
        >
          {features.map((feature, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 + idx * 0.07 }}
              className="glass-panel p-6 rounded-3xl flex flex-col items-start text-left hover:bg-white/[0.03] transition-colors relative overflow-hidden group"
            >
              {feature.badge && (
                <span className="absolute top-4 right-4 text-[10px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-full bg-primary/20 text-primary border border-primary/30">
                  {feature.badge}
                </span>
              )}
              <div className="p-3 bg-white/5 rounded-2xl mb-4">{feature.icon}</div>
              <h3 className="text-lg font-display font-semibold mb-2">{feature.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">{feature.description}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </div>
  );
}
