import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Play, Pause, RotateCcw, Zap, Coffee, Flame, Target } from "lucide-react";
import { useCreateSession, getGetSessionsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useAccuracy } from "@/hooks/useAccuracy";
import { useAlertMode } from "@/hooks/useAlertMode";

type SessionType = "work" | "short_break" | "long_break";
type Mood = "lazy" | "normal" | "focused";

const MOOD_CONFIG: Record<
  Mood,
  {
    label: string;
    emoji: string;
    icon: React.ReactNode;
    description: string;
    color: string;
    glow: string;
    work: number;
    short_break: number;
    long_break: number;
  }
> = {
  lazy: {
    label: "Lazy",
    emoji: "😴",
    icon: <Coffee className="w-4 h-4" />,
    description: "Gentle 15-min sessions",
    color: "text-blue-400",
    glow: "shadow-blue-500/20",
    work: 15,
    short_break: 3,
    long_break: 10,
  },
  normal: {
    label: "Normal",
    emoji: "😊",
    icon: <Zap className="w-4 h-4" />,
    description: "Classic 25-min Pomodoro",
    color: "text-primary",
    glow: "shadow-primary/20",
    work: 25,
    short_break: 5,
    long_break: 15,
  },
  focused: {
    label: "Focused",
    emoji: "🔥",
    icon: <Flame className="w-4 h-4" />,
    description: "Deep work 50-min blocks",
    color: "text-rose-400",
    glow: "shadow-rose-500/20",
    work: 50,
    short_break: 10,
    long_break: 20,
  },
};

const MODES: Record<SessionType, { label: string; stroke: string }> = {
  work: { label: "Focus", stroke: "stroke-primary" },
  short_break: { label: "Short Break", stroke: "stroke-emerald-400" },
  long_break: { label: "Long Break", stroke: "stroke-blue-400" },
};

export default function Timer() {
  const [mood, setMood] = useState<Mood>("normal");
  const [mode, setMode] = useState<SessionType>("work");
  const [timeLeft, setTimeLeft] = useState(MOOD_CONFIG["normal"].work * 60);
  const [isActive, setIsActive] = useState(false);
  const [sessionCount, setSessionCount] = useState(0);

  const timerStartedRef = useRef(false);

  const queryClient = useQueryClient();
  const createSession = useCreateSession({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetSessionsQueryKey() });
      },
    },
  });

  const { accuracy, grade, recordStart, recordComplete, started } = useAccuracy();
  const { fireAlert } = useAlertMode();

  const getModeMinutes = (m: SessionType) => MOOD_CONFIG[mood][m];

  useEffect(() => {
    setTimeLeft(getModeMinutes(mode) * 60);
    setIsActive(false);
    timerStartedRef.current = false;
  }, [mood, mode]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isActive && timeLeft > 0) {
      interval = setInterval(() => setTimeLeft((prev) => prev - 1), 1000);
    } else if (timeLeft === 0 && isActive) {
      setIsActive(false);
      if (mode === "work") {
        recordComplete();
        setSessionCount((c) => c + 1);
        createSession.mutate({
          data: { type: mode, durationMinutes: getModeMinutes(mode) },
        });
        fireAlert("success", "🎉 Session Complete!", `You completed a ${getModeMinutes(mode)}-min focus session. Time to rest!`);
        timerStartedRef.current = false;
        switchMode("short_break");
      } else {
        fireAlert("info", "☀️ Break Over", "Break finished — get back to work!");
        timerStartedRef.current = false;
        switchMode("work");
      }
    }
    return () => clearInterval(interval);
  }, [isActive, timeLeft, mode]);

  const switchMode = (newMode: SessionType) => {
    setMode(newMode);
    setTimeLeft(getModeMinutes(newMode) * 60);
    setIsActive(false);
    timerStartedRef.current = false;
  };

  const toggleTimer = () => {
    const starting = !isActive;
    setIsActive(starting);
    if (starting && mode === "work" && !timerStartedRef.current) {
      timerStartedRef.current = true;
      recordStart();
      if (started >= 2 && accuracy < 60) {
        fireAlert("warning", "⚠️ Low Accuracy Detected", `You're completing only ${accuracy}% of sessions. Try to commit to the full timer!`);
      }
    }
  };

  const resetTimer = () => {
    if (isActive && mode === "work" && timerStartedRef.current) {
      fireAlert("error", "⛔ Session Interrupted", "You reset a focus session. Try to stay committed!");
    }
    setIsActive(false);
    timerStartedRef.current = false;
    setTimeLeft(getModeMinutes(mode) * 60);
  };

  const formatTime = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m.toString().padStart(2, "0")}:${sec.toString().padStart(2, "0")}`;
  };

  const totalSeconds = getModeMinutes(mode) * 60;
  const progress = ((totalSeconds - timeLeft) / totalSeconds) * 100;
  const radius = 120;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (progress / 100) * circumference;
  const moodCfg = MOOD_CONFIG[mood];

  return (
    <div className="min-h-screen pt-24 pb-12 flex flex-col items-center justify-start px-4">
      {/* Mood Selector */}
      <motion.div
        initial={{ opacity: 0, y: -16 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md mb-6"
      >
        <p className="text-center text-xs uppercase tracking-widest text-muted-foreground font-medium mb-3">
          How are you feeling today?
        </p>
        <div className="grid grid-cols-3 gap-3">
          {(Object.entries(MOOD_CONFIG) as [Mood, typeof MOOD_CONFIG[Mood]][]).map(([key, cfg]) => (
            <button
              key={key}
              onClick={() => setMood(key)}
              className={`relative flex flex-col items-center gap-1.5 p-4 rounded-2xl border transition-all duration-300 ${
                mood === key
                  ? `border-primary/50 bg-primary/10 shadow-lg ${cfg.glow}`
                  : "border-white/5 bg-white/[0.02] hover:bg-white/[0.05] hover:border-white/10"
              }`}
            >
              {mood === key && (
                <motion.div
                  layoutId="mood-active"
                  className="absolute inset-0 rounded-2xl bg-gradient-to-br from-primary/10 to-transparent"
                  transition={{ type: "spring", stiffness: 300, damping: 30 }}
                />
              )}
              <span className="text-2xl relative z-10">{cfg.emoji}</span>
              <span className={`text-sm font-semibold relative z-10 ${mood === key ? cfg.color : "text-muted-foreground"}`}>
                {cfg.label}
              </span>
              <span className="text-[10px] text-muted-foreground/70 relative z-10 text-center leading-tight">
                {cfg.description}
              </span>
              {mood === key && (
                <div className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-primary rounded-full flex items-center justify-center shadow-lg">
                  <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                </div>
              )}
            </button>
          ))}
        </div>
      </motion.div>

      {/* Accuracy Badge */}
      {started > 0 && (
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className={`flex items-center gap-2 px-4 py-2 rounded-full border mb-4 text-sm font-medium ${grade.bg} ${grade.color}`}
        >
          <Target className="w-4 h-4" />
          <span>Session Accuracy: {accuracy}%</span>
          <span className="opacity-60 text-xs">— {grade.label}</span>
        </motion.div>
      )}

      {/* Timer Card */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md glass-panel p-8 rounded-[3rem] relative"
      >
        {/* Session Mode tabs */}
        <div className="flex bg-white/5 rounded-full p-1 mb-10">
          {(Object.entries(MODES) as [SessionType, typeof MODES[SessionType]][]).map(([m, cfg]) => (
            <button
              key={m}
              onClick={() => switchMode(m)}
              className={`flex-1 py-2 px-3 rounded-full text-sm font-medium transition-all duration-300 ${
                mode === m
                  ? "bg-white/10 text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground hover:bg-white/5"
              }`}
            >
              {cfg.label}
              <span className="ml-1 text-xs opacity-60">{getModeMinutes(m)}m</span>
            </button>
          ))}
        </div>

        {/* Circular Timer */}
        <div className="relative flex items-center justify-center mb-10">
          <svg className="w-72 h-72" style={{ transform: "rotate(-90deg)" }}>
            <circle cx="144" cy="144" r={radius} stroke="currentColor" strokeWidth="8" fill="transparent" className="text-white/5" />
            <motion.circle
              cx="144"
              cy="144"
              r={radius}
              stroke="currentColor"
              strokeWidth="8"
              fill="transparent"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              strokeLinecap="round"
              className={MODES[mode].stroke}
              style={{ transition: isActive ? "stroke-dashoffset 1s linear" : "none" }}
            />
          </svg>
          <div className="absolute flex flex-col items-center">
            <AnimatePresence mode="wait">
              <motion.span
                key={timeLeft}
                initial={{ opacity: 0.6, scale: 0.96 }}
                animate={{ opacity: 1, scale: 1 }}
                className={`text-6xl font-display font-bold tracking-tighter ${moodCfg.color}`}
              >
                {formatTime(timeLeft)}
              </motion.span>
            </AnimatePresence>
            <span className="text-muted-foreground mt-2 text-sm uppercase tracking-widest font-medium">
              {mode === "work" ? "Focusing" : "Resting"}
            </span>
            {sessionCount > 0 && (
              <div className="mt-2 flex items-center gap-1">
                {Array.from({ length: Math.min(sessionCount, 4) }).map((_, i) => (
                  <div key={i} className="w-2 h-2 rounded-full bg-primary/60" />
                ))}
                {sessionCount > 4 && (
                  <span className="text-xs text-muted-foreground ml-1">+{sessionCount - 4}</span>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center justify-center gap-6">
          <button
            onClick={resetTimer}
            className="w-14 h-14 flex items-center justify-center rounded-2xl bg-white/5 hover:bg-white/10 text-muted-foreground hover:text-foreground transition-all active:scale-95"
          >
            <RotateCcw className="w-6 h-6" />
          </button>

          <button
            onClick={toggleTimer}
            className={`w-20 h-20 flex items-center justify-center rounded-3xl text-white shadow-xl transition-all active:scale-95 ${
              isActive ? "bg-white/10 hover:bg-white/20" : `bg-primary hover:bg-primary/90 shadow-lg ${moodCfg.glow}`
            }`}
          >
            {isActive ? (
              <Pause className="w-8 h-8 fill-current" />
            ) : (
              <Play className="w-8 h-8 fill-current ml-1" />
            )}
          </button>

          <div className="w-14 h-14 flex flex-col items-center justify-center rounded-2xl bg-white/5 text-center">
            <span className="text-lg font-bold text-primary leading-none">{sessionCount}</span>
            <span className="text-[10px] text-muted-foreground">sessions</span>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
