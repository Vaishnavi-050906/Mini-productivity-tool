import { Link } from "wouter";
import { FileQuestion } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <div className="text-center max-w-md glass-panel p-12 rounded-[3rem]">
        <FileQuestion className="w-16 h-16 text-muted-foreground mx-auto mb-6" />
        <h1 className="text-3xl font-display font-bold mb-4">Page Not Found</h1>
        <p className="text-muted-foreground mb-8">
          The page you are looking for doesn't exist or has been moved.
        </p>
        <Link 
          href="/" 
          className="inline-flex bg-primary hover:bg-primary/90 text-white px-8 py-3 rounded-xl font-medium transition-colors shadow-lg shadow-primary/25"
        >
          Return Home
        </Link>
      </div>
    </div>
  );
}
