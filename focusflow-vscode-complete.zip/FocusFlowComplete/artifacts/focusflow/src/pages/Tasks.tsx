import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, Check, Trash2, Clock, Circle, CheckCircle2 } from "lucide-react";
import { format } from "date-fns";
import { 
  useGetTasks, 
  useCreateTask, 
  useUpdateTask, 
  useDeleteTask,
  getGetTasksQueryKey 
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
type TaskPriority = "low" | "medium" | "high";

export default function Tasks() {
  const [newTaskTitle, setNewTaskTitle] = useState("");
  const [priority, setPriority] = useState<TaskPriority>("medium");
  const [filter, setFilter] = useState<'all' | 'active' | 'completed'>('all');

  const queryClient = useQueryClient();
  const { data: tasks = [], isLoading } = useGetTasks();

  const invalidate = () => queryClient.invalidateQueries({ queryKey: getGetTasksQueryKey() });

  const createTask = useCreateTask({ mutation: { onSuccess: invalidate } });
  const updateTask = useUpdateTask({ mutation: { onSuccess: invalidate } });
  const deleteTask = useDeleteTask({ mutation: { onSuccess: invalidate } });

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim()) return;
    createTask.mutate({
      data: {
        title: newTaskTitle,
        priority: priority
      }
    });
    setNewTaskTitle("");
  };

  const toggleComplete = (id: number, current: boolean) => {
    updateTask.mutate({
      id,
      data: { completed: !current }
    });
  };

  const filteredTasks = tasks.filter(t => {
    if (filter === 'active') return !t.completed;
    if (filter === 'completed') return t.completed;
    return true;
  }).sort((a, b) => {
    if (a.completed !== b.completed) return a.completed ? 1 : -1;
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
  });

  return (
    <div className="min-h-screen pt-24 pb-12 px-4 max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className="text-4xl font-display font-bold mb-2">Tasks</h1>
        <p className="text-muted-foreground">Manage your priorities and stay on track.</p>
      </div>

      {/* Add Task Form */}
      <form onSubmit={handleAdd} className="glass-panel p-2 rounded-2xl flex items-center gap-2 mb-8 focus-within:ring-2 ring-primary/50 transition-all">
        <div className="flex-1 flex items-center gap-3 px-3">
          <Plus className="w-5 h-5 text-muted-foreground" />
          <input
            type="text"
            placeholder="Add a new task..."
            value={newTaskTitle}
            onChange={(e) => setNewTaskTitle(e.target.value)}
            className="w-full bg-transparent border-none outline-none text-foreground placeholder:text-muted-foreground py-3"
            disabled={createTask.isPending}
          />
        </div>
        <select 
          value={priority} 
          onChange={(e) => setPriority(e.target.value as TaskPriority)}
          className="bg-secondary text-sm border-none rounded-xl px-3 py-3 outline-none cursor-pointer"
        >
          <option value="low">Low</option>
          <option value="medium">Medium</option>
          <option value="high">High</option>
        </select>
        <button
          type="submit"
          disabled={!newTaskTitle.trim() || createTask.isPending}
          className="bg-primary hover:bg-primary/90 text-white px-6 py-3 rounded-xl font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Add
        </button>
      </form>

      {/* Filters */}
      <div className="flex gap-2 mb-6">
        {(['all', 'active', 'completed'] as const).map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-4 py-2 rounded-full text-sm font-medium capitalize transition-colors ${
              filter === f ? 'bg-white/10 text-foreground' : 'text-muted-foreground hover:bg-white/5'
            }`}
          >
            {f}
          </button>
        ))}
      </div>

      {/* Task List */}
      <div className="space-y-3">
        {isLoading ? (
          <div className="text-center py-12 text-muted-foreground">Loading tasks...</div>
        ) : filteredTasks.length === 0 ? (
          <div className="text-center py-12 glass-panel rounded-3xl">
            <CheckCircle2 className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
            <p className="text-muted-foreground">No tasks found. You're all caught up!</p>
          </div>
        ) : (
          <AnimatePresence>
            {filteredTasks.map((task) => (
              <motion.div
                layout
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                key={task.id}
                className={`group glass-panel p-4 rounded-2xl flex items-center gap-4 transition-all ${
                  task.completed ? 'opacity-60 bg-white/[0.02]' : 'hover:bg-white/[0.04]'
                }`}
              >
                <button
                  onClick={() => toggleComplete(task.id, task.completed)}
                  className={`flex-shrink-0 w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors ${
                    task.completed 
                      ? 'bg-primary border-primary text-white' 
                      : 'border-muted-foreground hover:border-primary'
                  }`}
                >
                  {task.completed && <Check className="w-4 h-4" />}
                </button>
                
                <div className="flex-1 min-w-0">
                  <h3 className={`font-medium truncate transition-colors ${task.completed ? 'line-through text-muted-foreground' : 'text-foreground'}`}>
                    {task.title}
                  </h3>
                  <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {format(new Date(task.createdAt), 'MMM d, h:mm a')}
                    </span>
                    <span className="flex items-center gap-1">
                      <Circle className={`w-2 h-2 ${
                        task.priority === 'high' ? 'text-destructive fill-destructive' :
                        task.priority === 'medium' ? 'text-accent fill-accent' :
                        'text-muted-foreground fill-muted-foreground'
                      }`} />
                      <span className="capitalize">{task.priority}</span>
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => deleteTask.mutate({ id: task.id })}
                  className="opacity-0 group-hover:opacity-100 p-2 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-xl transition-all"
                  aria-label="Delete task"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </motion.div>
            ))}
          </AnimatePresence>
        )}
      </div>
    </div>
  );
}

