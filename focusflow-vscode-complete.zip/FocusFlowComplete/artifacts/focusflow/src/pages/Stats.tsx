import { useMemo } from "react";
import { useGetSessions, useGetTasks } from "@workspace/api-client-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { Brain, CheckCircle2, Timer, Award, Flame, Star, Zap, TrendingUp, Target, RotateCcw } from "lucide-react";
import { motion } from "framer-motion";
import { useGamification, LEVELS } from "@/hooks/useGamification";
import { useAccuracy } from "@/hooks/useAccuracy";
import { useAlertMode } from "@/hooks/useAlertMode";

export default function Stats() {
  const { data: sessions = [], isLoading: loadingSessions } = useGetSessions();
  const { data: tasks = [], isLoading: loadingTasks } = useGetTasks();
  const {
    totalPoints,
    taskPoints,
    sessionPoints,
    bonusPoints,
    currentLevel,
    nextLevel,
    pointsToNextLevel,
    progressToNextLevel,
    focusScore,
    streakDays,
    completedTasksCount,
    totalTasksCount,
    totalFocusMinutes,
  } = useGamification();
  const { accuracy, grade, started, completed, resetAccuracy } = useAccuracy();
  const { alertMode, toggleAlertMode } = useAlertMode();

  const chartData = useMemo(() => {
    const focusSessions = sessions.filter((s) => s.type === "work");
    const last7Days = Array.from({ length: 7 }).map((_, i) => {
      const d = new Date();
      d.setDate(d.getDate() - (6 - i));
      return {
        date: d.toLocaleDateString("en-US", { weekday: "short" }),
        fullDate: d.toDateString(),
        minutes: 0,
      };
    });
    focusSessions.forEach((s) => {
      const day = last7Days.find((d) => new Date(s.completedAt).toDateString() === d.fullDate);
      if (day) day.minutes += s.durationMinutes;
    });
    return last7Days;
  }, [sessions]);

  if (loadingSessions || loadingTasks) {
    return (
      <div className="min-h-screen flex items-center justify-center text-muted-foreground">
        Loading stats...
      </div>
    );
  }

  const scoreColor =
    focusScore >= 80
      ? "text-emerald-400"
      : focusScore >= 50
      ? "text-primary"
      : "text-amber-400";

  return (
    <div className="min-h-screen pt-24 pb-12 px-4 max-w-6xl mx-auto">
      <div className="mb-10">
        <h1 className="text-4xl font-display font-bold mb-2">Focus Stats</h1>
        <p className="text-muted-foreground">Your productivity footprint at a glance.</p>
      </div>

      {/* Level & Gamification Card */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-panel p-6 md:p-8 rounded-3xl mb-8 border border-primary/20 relative overflow-hidden"
      >
        {/* Background glow */}
        <div className="absolute -top-20 -right-20 w-64 h-64 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-20 -left-20 w-64 h-64 bg-accent/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center gap-8">
          {/* Level Badge */}
          <div className="flex-shrink-0 text-center">
            <div className="relative inline-block">
              <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-primary/30 to-accent/30 border border-primary/30 flex items-center justify-center text-5xl shadow-2xl shadow-primary/20">
                {currentLevel.badge}
              </div>
              <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white text-sm font-bold shadow-lg">
                {currentLevel.level}
              </div>
            </div>
            <p className={`mt-3 font-display font-bold text-lg ${currentLevel.color}`}>
              {currentLevel.title}
            </p>
            <p className="text-xs text-muted-foreground">Level {currentLevel.level}</p>
          </div>

          {/* Points & Progress */}
          <div className="flex-1 w-full">
            <div className="flex items-baseline gap-3 mb-1">
              <span className="text-4xl font-display font-extrabold text-foreground">
                {totalPoints.toLocaleString()}
              </span>
              <span className="text-muted-foreground text-sm">total points</span>
            </div>
            <div className="flex items-center gap-4 mb-4 flex-wrap text-sm">
              <span className="text-muted-foreground flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                {taskPoints} task pts
              </span>
              <span className="text-muted-foreground flex items-center gap-1">
                <Timer className="w-3.5 h-3.5 text-primary" />
                {sessionPoints} session pts
              </span>
              {bonusPoints > 0 && (
                <span className="text-amber-400 flex items-center gap-1">
                  <Star className="w-3.5 h-3.5" />
                  +{bonusPoints} bonus
                </span>
              )}
            </div>
            {nextLevel ? (
              <>
                <div className="flex justify-between text-xs text-muted-foreground mb-2">
                  <span>Progress to {nextLevel.title}</span>
                  <span>{pointsToNextLevel} pts to go</span>
                </div>
                <div className="h-3 bg-white/5 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${progressToNextLevel}%` }}
                    transition={{ duration: 1, ease: "easeOut", delay: 0.3 }}
                    className="h-full rounded-full bg-gradient-to-r from-primary to-accent"
                  />
                </div>
              </>
            ) : (
              <div className="text-amber-400 font-semibold flex items-center gap-2">
                <Star className="w-4 h-4" />
                Max Level Reached — You're a Legend!
              </div>
            )}
          </div>

          {/* Level Milestones */}
          <div className="hidden lg:flex flex-col gap-1.5">
            {LEVELS.map((l) => (
              <div
                key={l.level}
                className={`flex items-center gap-2 text-sm ${
                  l.level <= currentLevel.level ? l.color : "text-muted-foreground/40"
                }`}
              >
                <span>{l.badge}</span>
                <span className="font-medium">{l.title}</span>
                {l.level <= currentLevel.level && (
                  <CheckCircle2 className="w-3 h-3 ml-auto" />
                )}
              </div>
            ))}
          </div>
        </div>
      </motion.div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
        {[
          {
            title: "Focus Score",
            value: `${focusScore}`,
            unit: "/ 100",
            icon: <Zap className="w-5 h-5 text-primary" />,
            color: `bg-primary/10 border-primary/20 ${scoreColor}`,
            sub: focusScore >= 80 ? "Excellent!" : focusScore >= 50 ? "Good work" : "Keep going",
          },
          {
            title: "Session Accuracy",
            value: `${accuracy}%`,
            unit: "",
            icon: <Target className="w-5 h-5" style={{ color: "currentColor" }} />,
            color: `${grade.bg} ${grade.color}`,
            sub: started > 0 ? `${completed}/${started} sessions finished — ${grade.label}` : "Start a session to track",
          },
          {
            title: "Total Focus",
            value: `${Math.floor(totalFocusMinutes / 60)}h ${totalFocusMinutes % 60}m`,
            unit: "",
            icon: <Timer className="w-5 h-5 text-blue-400" />,
            color: "bg-blue-400/10 border-blue-400/20 text-blue-400",
            sub: `${sessions.filter((s) => s.type === "work").length} sessions`,
          },
          {
            title: "Tasks Done",
            value: `${completedTasksCount}`,
            unit: `/ ${totalTasksCount}`,
            icon: <CheckCircle2 className="w-5 h-5 text-emerald-400" />,
            color: "bg-emerald-400/10 border-emerald-400/20 text-emerald-400",
            sub: totalTasksCount > 0 ? `${Math.round((completedTasksCount / totalTasksCount) * 100)}% complete` : "No tasks yet",
          },
          {
            title: "Streak",
            value: `${streakDays}`,
            unit: "days",
            icon: <Flame className="w-5 h-5 text-rose-400" />,
            color: "bg-rose-400/10 border-rose-400/20 text-rose-400",
            sub: streakDays > 0 ? "Keep it up!" : "Start today!",
          },
        ].map((card, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.08 }}
            className={`glass-panel p-5 rounded-3xl border flex flex-col justify-between h-36 ${card.color}`}
          >
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground text-sm font-medium">{card.title}</span>
              <div className="p-1.5 bg-background/40 rounded-xl">{card.icon}</div>
            </div>
            <div>
              <div className="text-2xl font-display font-bold text-foreground">
                {card.value}
                {card.unit && <span className="text-sm font-normal text-muted-foreground ml-1">{card.unit}</span>}
              </div>
              <p className="text-xs text-muted-foreground mt-0.5">{card.sub}</p>
            </div>
          </motion.div>
        ))}

        {/* Alert Mode Control Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className={`glass-panel p-5 rounded-3xl border flex flex-col justify-between h-36 transition-all duration-300 ${
            alertMode
              ? "bg-rose-500/10 border-rose-500/30"
              : "bg-white/[0.02] border-white/10"
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground text-sm font-medium">Alert Mode</span>
            <button
              onClick={toggleAlertMode}
              className={`relative w-11 h-6 rounded-full transition-all duration-300 ${
                alertMode ? "bg-rose-500" : "bg-white/10"
              }`}
            >
              <span
                className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow transition-all duration-300 ${
                  alertMode ? "left-6" : "left-1"
                }`}
              />
            </button>
          </div>
          <div>
            <div className={`text-lg font-display font-bold ${alertMode ? "text-rose-400" : "text-muted-foreground"}`}>
              {alertMode ? "🔔 Active" : "🔕 Inactive"}
            </div>
            <p className="text-xs text-muted-foreground mt-0.5">
              {alertMode ? "Alerts on for sessions & issues" : "Toggle for smart alerts"}
            </p>
          </div>
        </motion.div>
      </div>

      {/* Focus Score breakdown */}
      <div className="grid md:grid-cols-2 gap-6 mb-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="glass-panel p-6 rounded-3xl"
        >
          <h2 className="text-lg font-display font-semibold mb-4 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-primary" />
            Focus Score Breakdown
          </h2>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-1.5">
                <span className="text-muted-foreground">Task Completion</span>
                <span className="font-medium">
                  {totalTasksCount > 0
                    ? Math.round((completedTasksCount / totalTasksCount) * 50)
                    : 0}
                  / 50
                </span>
              </div>
              <div className="h-2 bg-white/5 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{
                    width: `${totalTasksCount > 0 ? (completedTasksCount / totalTasksCount) * 100 : 0}%`,
                  }}
                  transition={{ duration: 1, ease: "easeOut", delay: 0.5 }}
                  className="h-full rounded-full bg-emerald-400"
                />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1.5">
                <span className="text-muted-foreground">Focus Time (goal: 120min)</span>
                <span className="font-medium">
                  {Math.min(Math.round((totalFocusMinutes / 120) * 50), 50)} / 50
                </span>
              </div>
              <div className="h-2 bg-white/5 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{
                    width: `${Math.min((totalFocusMinutes / 120) * 100, 100)}%`,
                  }}
                  transition={{ duration: 1, ease: "easeOut", delay: 0.6 }}
                  className="h-full rounded-full bg-primary"
                />
              </div>
            </div>
            <div className="pt-3 border-t border-white/5 flex items-center justify-between">
              <span className="font-semibold text-foreground">Total Score</span>
              <span className={`text-2xl font-display font-extrabold ${scoreColor}`}>
                {focusScore} / 100
              </span>
            </div>
          </div>
        </motion.div>

        {/* Points Breakdown */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.35 }}
          className="glass-panel p-6 rounded-3xl"
        >
          <h2 className="text-lg font-display font-semibold mb-4 flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-400" />
            Points Breakdown
          </h2>
          <div className="space-y-3">
            {[
              {
                label: "Tasks completed",
                desc: `${completedTasksCount} × 10 pts`,
                value: taskPoints,
                color: "text-emerald-400",
              },
              {
                label: "Focus sessions",
                desc: `${sessions.filter((s) => s.type === "work").length} × 5 pts`,
                value: sessionPoints,
                color: "text-primary",
              },
              {
                label: "Milestone bonuses",
                desc: `Every 5 tasks = +20 pts`,
                value: bonusPoints,
                color: "text-amber-400",
              },
            ].map((item, i) => (
              <div key={i} className="flex items-center justify-between py-2 border-b border-white/5 last:border-0">
                <div>
                  <p className="text-sm font-medium text-foreground">{item.label}</p>
                  <p className="text-xs text-muted-foreground">{item.desc}</p>
                </div>
                <span className={`font-display font-bold text-lg ${item.color}`}>
                  +{item.value}
                </span>
              </div>
            ))}
            <div className="flex items-center justify-between pt-3">
              <span className="font-semibold">Total Points</span>
              <span className="text-2xl font-display font-extrabold text-primary">
                {totalPoints}
              </span>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Bar Chart */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="glass-panel p-8 rounded-3xl"
      >
        <h2 className="text-xl font-display font-semibold mb-8">Focus Minutes (Last 7 Days)</h2>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
              <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{ fill: "#888", fontSize: 13 }} dy={10} />
              <YAxis axisLine={false} tickLine={false} tick={{ fill: "#888", fontSize: 13 }} />
              <Tooltip
                cursor={{ fill: "rgba(255,255,255,0.04)" }}
                contentStyle={{ backgroundColor: "#13121A", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "12px" }}
                labelStyle={{ color: "#888", marginBottom: "4px" }}
                itemStyle={{ color: "#fff", fontWeight: 600 }}
              />
              <Bar dataKey="minutes" radius={[6, 6, 6, 6]} name="Minutes">
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.minutes > 0 ? "hsl(var(--primary))" : "hsl(var(--muted))"} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </motion.div>
    </div>
  );
}
