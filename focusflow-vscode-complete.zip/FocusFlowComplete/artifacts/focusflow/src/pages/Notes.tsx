import { useState } from "react";
import { motion } from "framer-motion";
import { Plus, Edit2, Trash2 } from "lucide-react";
import { format } from "date-fns";
import { 
  useGetNotes, 
  useCreateNote, 
  useUpdateNote, 
  useDeleteNote,
  getGetNotesQueryKey 
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Modal } from "@/components/Modal";

export default function Notes() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");

  const queryClient = useQueryClient();
  const { data: notes = [], isLoading } = useGetNotes();

  const invalidate = () => queryClient.invalidateQueries({ queryKey: getGetNotesQueryKey() });

  const createNote = useCreateNote({ mutation: { onSuccess: invalidate } });
  const updateNote = useUpdateNote({ mutation: { onSuccess: invalidate } });
  const deleteNote = useDeleteNote({ mutation: { onSuccess: invalidate } });

  const openNewNote = () => {
    setEditingId(null);
    setTitle("");
    setContent("");
    setIsModalOpen(true);
  };

  const openEditNote = (note: any) => {
    setEditingId(note.id);
    setTitle(note.title);
    setContent(note.content);
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) return;

    if (editingId) {
      updateNote.mutate({
        id: editingId,
        data: { title, content }
      });
    } else {
      createNote.mutate({
        data: { title, content }
      });
    }
    setIsModalOpen(false);
  };

  return (
    <div className="min-h-screen pt-24 pb-12 px-4 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-4xl font-display font-bold mb-2">Quick Notes</h1>
          <p className="text-muted-foreground">Capture your ideas before they escape.</p>
        </div>
        <button
          onClick={openNewNote}
          className="inline-flex items-center gap-2 bg-primary hover:bg-primary/90 text-white px-6 py-3 rounded-xl font-medium transition-colors shadow-lg shadow-primary/25"
        >
          <Plus className="w-5 h-5" />
          New Note
        </button>
      </div>

      {isLoading ? (
        <div className="text-center py-12 text-muted-foreground">Loading notes...</div>
      ) : notes.length === 0 ? (
        <div className="text-center py-24 glass-panel rounded-3xl">
          <p className="text-lg text-muted-foreground mb-4">No notes yet. Start writing!</p>
          <button onClick={openNewNote} className="text-primary hover:underline">Create your first note</button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {notes.map((note) => (
            <motion.div
              layout
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              key={note.id}
              className="glass-panel p-6 rounded-3xl hover:-translate-y-1 transition-all duration-300 group relative flex flex-col h-64"
            >
              <div className="absolute top-4 right-4 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button
                  onClick={() => openEditNote(note)}
                  className="p-2 bg-secondary/80 hover:bg-secondary backdrop-blur rounded-lg text-muted-foreground hover:text-foreground transition-colors"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => deleteNote.mutate({ id: note.id })}
                  className="p-2 bg-secondary/80 hover:bg-destructive/20 backdrop-blur rounded-lg text-muted-foreground hover:text-destructive transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              <h3 className="text-xl font-display font-semibold mb-3 pr-16 line-clamp-2">{note.title}</h3>
              <p className="text-muted-foreground text-sm line-clamp-4 flex-1 whitespace-pre-wrap">
                {note.content}
              </p>
              
              <div className="mt-4 pt-4 border-t border-white/5 text-xs text-muted-foreground/60 font-medium uppercase tracking-wider">
                {format(new Date(note.updatedAt), 'MMM d, yyyy')}
              </div>
            </motion.div>
          ))}
        </div>
      )}

      <Modal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        title={editingId ? "Edit Note" : "New Note"}
      >
        <form onSubmit={handleSave} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-muted-foreground mb-1.5">Title</label>
            <input
              autoFocus
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Meeting notes..."
              className="w-full bg-secondary border border-white/5 rounded-xl px-4 py-3 text-foreground outline-none focus:ring-2 ring-primary/50 transition-all"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-muted-foreground mb-1.5">Content</label>
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Write your thoughts here..."
              rows={6}
              className="w-full bg-secondary border border-white/5 rounded-xl px-4 py-3 text-foreground outline-none focus:ring-2 ring-primary/50 transition-all resize-none"
            />
          </div>
          <div className="pt-2 flex justify-end gap-3">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-5 py-2.5 rounded-xl font-medium text-muted-foreground hover:bg-white/5 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!title.trim() || !content.trim() || createNote.isPending || updateNote.isPending}
              className="px-6 py-2.5 bg-primary hover:bg-primary/90 text-white rounded-xl font-medium shadow-lg shadow-primary/25 disabled:opacity-50 transition-colors"
            >
              {editingId ? "Save Changes" : "Create Note"}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
