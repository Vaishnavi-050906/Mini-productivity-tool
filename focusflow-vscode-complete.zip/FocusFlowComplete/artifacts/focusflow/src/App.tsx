import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "sonner";
import { Navbar } from "./components/Navbar";

// Pages
import Landing from "./pages/Landing";
import Timer from "./pages/Timer";
import Tasks from "./pages/Tasks";
import Notes from "./pages/Notes";
import Stats from "./pages/Stats";
import NotFound from "./pages/not-found";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      staleTime: 1000 * 60 * 5, // 5 minutes
    }
  }
});

function Router() {
  return (
    <>
      <Navbar />
      <main className="relative z-0">
        <Switch>
          <Route path="/" component={Landing} />
          <Route path="/timer" component={Timer} />
          <Route path="/tasks" component={Tasks} />
          <Route path="/notes" component={Notes} />
          <Route path="/stats" component={Stats} />
          <Route component={NotFound} />
        </Switch>
      </main>
    </>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
        <Router />
      </WouterRouter>
      <Toaster
        position="bottom-right"
        theme="dark"
        toastOptions={{
          style: {
            background: "hsl(240 10% 10%)",
            border: "1px solid hsl(240 10% 18%)",
            color: "hsl(0 0% 95%)",
          },
        }}
      />
    </QueryClientProvider>
  );
}

export default App;
