import { Link, useLocation } from "wouter";
import { motion } from "framer-motion";
import { Brain, CheckCircle2, FileText, BarChart2, Timer, Bell, BellOff } from "lucide-react";
import { cn } from "@/lib/utils";
import { useGamification } from "@/hooks/useGamification";
import { useAlertMode } from "@/hooks/useAlertMode";

export function Navbar() {
  const [location] = useLocation();
  const { totalPoints, currentLevel, progressToNextLevel } = useGamification();
  const { alertMode, toggleAlertMode } = useAlertMode();

  const links = [
    { href: "/timer", label: "Timer", icon: Timer },
    { href: "/tasks", label: "Tasks", icon: CheckCircle2 },
    { href: "/notes", label: "Notes", icon: FileText },
    { href: "/stats", label: "Stats", icon: BarChart2 },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-40 flex justify-center py-4 px-4 pointer-events-none">
      <div className="glass-panel rounded-full px-4 py-2 flex items-center gap-2 md:gap-4 pointer-events-auto">
        <Link href="/" className="flex items-center gap-2 mr-2 group px-2 py-1">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-lg shadow-primary/25 group-hover:shadow-primary/40 transition-shadow">
            <Brain className="w-5 h-5 text-white" />
          </div>
          <span className="font-display font-bold text-lg hidden md:block tracking-wide">
            FocusFlow
          </span>
        </Link>

        <div className="flex items-center gap-1">
          {links.map((link) => {
            const isActive = location === link.href;
            const Icon = link.icon;
            return (
              <Link
                key={link.href}
                href={link.href}
                className={cn(
                  "relative px-3 py-2 md:px-4 md:py-2 rounded-full text-sm font-medium transition-colors flex items-center gap-2",
                  isActive
                    ? "text-primary-foreground"
                    : "text-muted-foreground hover:text-foreground hover:bg-white/5"
                )}
              >
                {isActive && (
                  <motion.div
                    layoutId="navbar-active"
                    className="absolute inset-0 bg-primary/20 border border-primary/30 rounded-full -z-10"
                    transition={{ type: "spring", stiffness: 300, damping: 30 }}
                  />
                )}
                <Icon className={cn("w-4 h-4", isActive ? "text-primary" : "")} />
                <span className="hidden sm:block">{link.label}</span>
              </Link>
            );
          })}
        </div>

        {/* Alert Mode Toggle */}
        <button
          onClick={toggleAlertMode}
          title={alertMode ? "Alert Mode ON — click to disable" : "Alert Mode OFF — click to enable"}
          className={cn(
            "relative w-9 h-9 flex items-center justify-center rounded-full border transition-all duration-300",
            alertMode
              ? "bg-rose-500/20 border-rose-500/40 text-rose-400 shadow-lg shadow-rose-500/10"
              : "bg-white/5 border-white/10 text-muted-foreground hover:text-foreground hover:bg-white/10"
          )}
        >
          {alertMode ? <Bell className="w-4 h-4" /> : <BellOff className="w-4 h-4" />}
          {alertMode && (
            <span className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-rose-500 rounded-full animate-pulse" />
          )}
        </button>

        {/* Level/Points Badge */}
        <Link href="/stats" className="hidden sm:flex items-center gap-2 group">
          <div className="relative flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 transition-all cursor-pointer">
            <span className="text-base leading-none">{currentLevel.badge}</span>
            <div className="flex flex-col">
              <span className={`text-xs font-bold leading-none ${currentLevel.color}`}>
                Lv.{currentLevel.level}
              </span>
              <span className="text-[10px] text-muted-foreground leading-none mt-0.5">
                {totalPoints} pts
              </span>
            </div>
            <div className="w-12 h-1 bg-white/10 rounded-full overflow-hidden ml-1">
              <motion.div
                animate={{ width: `${progressToNextLevel}%` }}
                transition={{ duration: 0.8, ease: "easeOut" }}
                className="h-full rounded-full bg-gradient-to-r from-primary to-accent"
              />
            </div>
          </div>
        </Link>
      </div>
    </nav>
  );
}
