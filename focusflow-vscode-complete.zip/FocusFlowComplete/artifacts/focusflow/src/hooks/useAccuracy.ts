import { useState, useCallback } from "react";

const STARTED_KEY = "ff_sessions_started";
const COMPLETED_KEY = "ff_sessions_completed";

function getStored(key: string): number {
  return parseInt(localStorage.getItem(key) ?? "0", 10);
}

export function useAccuracy() {
  const [started, setStarted] = useState(() => getStored(STARTED_KEY));
  const [completed, setCompleted] = useState(() => getStored(COMPLETED_KEY));

  const recordStart = useCallback(() => {
    const next = getStored(STARTED_KEY) + 1;
    localStorage.setItem(STARTED_KEY, String(next));
    setStarted(next);
  }, []);

  const recordComplete = useCallback(() => {
    const next = getStored(COMPLETED_KEY) + 1;
    localStorage.setItem(COMPLETED_KEY, String(next));
    setCompleted(next);
  }, []);

  const resetAccuracy = useCallback(() => {
    localStorage.setItem(STARTED_KEY, "0");
    localStorage.setItem(COMPLETED_KEY, "0");
    setStarted(0);
    setCompleted(0);
  }, []);

  const accuracy = started === 0 ? 100 : Math.round((completed / started) * 100);
  const grade =
    accuracy >= 90 ? { label: "Excellent", color: "text-emerald-400", bg: "bg-emerald-400/10 border-emerald-400/20" } :
    accuracy >= 70 ? { label: "Good",      color: "text-blue-400",    bg: "bg-blue-400/10 border-blue-400/20" } :
    accuracy >= 50 ? { label: "Fair",      color: "text-amber-400",   bg: "bg-amber-400/10 border-amber-400/20" } :
                     { label: "Low",       color: "text-rose-400",    bg: "bg-rose-400/10 border-rose-400/20" };

  return { started, completed, accuracy, grade, recordStart, recordComplete, resetAccuracy };
}
