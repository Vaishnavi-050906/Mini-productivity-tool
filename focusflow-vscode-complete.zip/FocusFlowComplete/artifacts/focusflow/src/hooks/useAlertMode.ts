import { useState, useCallback } from "react";
import { toast } from "sonner";

const ALERT_KEY = "ff_alert_mode";

export type AlertType = "success" | "warning" | "error" | "info";

export function useAlertMode() {
  const [alertMode, setAlertMode] = useState<boolean>(
    () => localStorage.getItem(ALERT_KEY) === "true"
  );

  const toggleAlertMode = useCallback(async () => {
    const next = !alertMode;
    if (next && "Notification" in window && Notification.permission === "default") {
      await Notification.requestPermission();
    }
    localStorage.setItem(ALERT_KEY, String(next));
    setAlertMode(next);
    toast(next ? "🔔 Alert Mode ON" : "🔕 Alert Mode OFF", {
      description: next
        ? "You'll get notified about session events & issues."
        : "Alerts are now silenced.",
      duration: 3000,
    });
  }, [alertMode]);

  const fireAlert = useCallback(
    (type: AlertType, title: string, description?: string) => {
      if (!alertMode) return;

      const opts = { description, duration: 5000 };
      if (type === "success") toast.success(title, opts);
      else if (type === "warning") toast.warning(title, opts);
      else if (type === "error") toast.error(title, opts);
      else toast.info(title, opts);

      if ("Notification" in window && Notification.permission === "granted") {
        new Notification(title, {
          body: description,
          icon: "/favicon.ico",
          badge: "/favicon.ico",
        });
      }
    },
    [alertMode]
  );

  return { alertMode, toggleAlertMode, fireAlert };
}
