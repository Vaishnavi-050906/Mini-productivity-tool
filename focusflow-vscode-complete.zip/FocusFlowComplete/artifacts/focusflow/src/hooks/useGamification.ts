import { useMemo } from "react";
import { useGetTasks, useGetSessions } from "@workspace/api-client-react";

export const LEVELS = [
  { level: 1, title: "Rookie", minPoints: 0, color: "text-slate-400", badge: "🌱" },
  { level: 2, title: "Apprentice", minPoints: 100, color: "text-emerald-400", badge: "🌿" },
  { level: 3, title: "Productive", minPoints: 300, color: "text-blue-400", badge: "⚡" },
  { level: 4, title: "Focused", minPoints: 700, color: "text-violet-400", badge: "🔥" },
  { level: 5, title: "Elite", minPoints: 1500, color: "text-amber-400", badge: "⭐" },
  { level: 6, title: "Legend", minPoints: 3000, color: "text-rose-400", badge: "👑" },
];

export function useGamification() {
  const { data: tasks = [] } = useGetTasks();
  const { data: sessions = [] } = useGetSessions();

  return useMemo(() => {
    const completedTasks = tasks.filter((t) => t.completed);
    const focusSessions = sessions.filter((s) => s.type === "work");
    const totalFocusMinutes = focusSessions.reduce((sum, s) => sum + s.durationMinutes, 0);

    const taskPoints = completedTasks.length * 10;
    const sessionPoints = focusSessions.length * 5;
    const bonusPoints = Math.floor(completedTasks.length / 5) * 20;
    const totalPoints = taskPoints + sessionPoints + bonusPoints;

    const currentLevelData =
      LEVELS.slice()
        .reverse()
        .find((l) => totalPoints >= l.minPoints) ?? LEVELS[0];

    const nextLevelData = LEVELS.find((l) => l.level === currentLevelData.level + 1);
    const pointsToNextLevel = nextLevelData
      ? nextLevelData.minPoints - totalPoints
      : 0;
    const progressToNextLevel = nextLevelData
      ? ((totalPoints - currentLevelData.minPoints) /
          (nextLevelData.minPoints - currentLevelData.minPoints)) *
        100
      : 100;

    const focusScore = Math.min(
      100,
      Math.round(
        (completedTasks.length / Math.max(tasks.length, 1)) * 50 +
          Math.min(totalFocusMinutes / 120, 1) * 50
      )
    );

    const streakDays = (() => {
      if (focusSessions.length === 0) return 0;
      const today = new Date();
      let streak = 0;
      for (let i = 0; i < 30; i++) {
        const d = new Date(today);
        d.setDate(d.getDate() - i);
        const dateStr = d.toDateString();
        const hasSession = focusSessions.some(
          (s) => new Date(s.completedAt).toDateString() === dateStr
        );
        if (hasSession) streak++;
        else if (i > 0) break;
      }
      return streak;
    })();

    return {
      totalPoints,
      taskPoints,
      sessionPoints,
      bonusPoints,
      currentLevel: currentLevelData,
      nextLevel: nextLevelData,
      pointsToNextLevel,
      progressToNextLevel,
      focusScore,
      streakDays,
      completedTasksCount: completedTasks.length,
      totalTasksCount: tasks.length,
      totalFocusMinutes,
    };
  }, [tasks, sessions]);
}
